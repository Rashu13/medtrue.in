import 'package:broadcast_app/screens/user_entry_screen.dart';
import 'package:broadcast_app/utils/constants.dart';
import 'package:flutter/material.dart';
import 'package:get_storage/get_storage.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  await GetStorage.init();

  await Supabase.initialize(
    url: AppConstants.supabaseUrl,
    anonKey: AppConstants.supabaseAnonKey,
  );

  runApp(const MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  late final TextEditingController _phoneController;
  late final TextEditingController _appIdController;

  @override
  void initState() {
    super.initState();
    _phoneController = TextEditingController();
    _appIdController = TextEditingController();
  }

  @override
  void dispose() {
    _phoneController.dispose();
    _appIdController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Broadcast App',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        useMaterial3: true,
      ),
      home: UserEntryScreen(
        phoneController: _phoneController,
        appIdController: _appIdController,
      ),
    );
  }
}
