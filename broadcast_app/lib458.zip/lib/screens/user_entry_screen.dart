import 'package:broadcast_app/screens/simple_chat_screen.dart';
import 'package:broadcast_app/utils/constants.dart';
import 'package:flutter/material.dart';

class UserEntryScreen extends StatefulWidget {
  final TextEditingController phoneController;
  final TextEditingController appIdController;

  const UserEntryScreen({
    super.key,
    required this.phoneController,
    required this.appIdController,
  });

  @override
  State<UserEntryScreen> createState() => _UserEntryScreenState();
}

class _UserEntryScreenState extends State<UserEntryScreen> {
  bool isLoading = false;

  Future<void> _startChat() async {
    final phone = widget.phoneController.text.trim();
    final appId = widget.appIdController.text.trim();

    if (phone.isEmpty || appId.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please enter both Phone Number and App ID')),
      );
      return;
    }

    setState(() => isLoading = true);

    // Sync user to DB so Admin can see them
    try {
      // Check if user already exists to preserve 'admin' role
      final existingUser = await supabase
          .from('tbl_profiles')
          .select('role')
          .eq('id', appId)
          .maybeSingle();

      String role = 'user';
      if (existingUser != null && existingUser['role'] == 'admin') {
        role = 'admin';
      }

      await supabase.from('tbl_profiles').upsert({
        'id': appId, // Using App ID as the primary key
        'email': phone, // Saving Phone in Email column for Admin visibility
        'role': role,
      });
    } catch (e) {
      // If write fails (RLS or otherwise), we log but proceed so chat works
      debugPrint('Failed to sync profile: $e');
    } finally {
      if (mounted) setState(() => isLoading = false);
    }

    if (!mounted) return;

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => SimpleChatScreen(
          phoneNumber: phone,
          appId: appId,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Connect to Support')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            TextField(
              controller: widget.phoneController,
              keyboardType: TextInputType.phone,
              decoration: const InputDecoration(
                labelText: 'Phone Number',
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.phone),
              ),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: widget.appIdController,
              decoration: const InputDecoration(
                labelText: 'App ID (Unique Identifier)',
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.fingerprint),
              ),
            ),
            const SizedBox(height: 24),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: isLoading ? null : _startChat,
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  backgroundColor: Colors.blue,
                  foregroundColor: Colors.white,
                ),
                child: isLoading 
                  ? const SizedBox(height: 20, width: 20, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                  : const Text('Start Chat'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
