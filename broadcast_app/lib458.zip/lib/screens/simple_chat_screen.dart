import 'package:broadcast_app/models/message.dart';
import 'package:broadcast_app/utils/constants.dart';
import 'package:broadcast_app/utils/encryption_helper.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class SimpleChatScreen extends StatefulWidget {
  final String phoneNumber;
  final String appId;
  final String? adminId; // Optional: Pass specific admin ID if known

  const SimpleChatScreen({
    super.key,
    required this.phoneNumber,
    required this.appId,
    this.adminId,
  });

  @override
  State<SimpleChatScreen> createState() => _SimpleChatScreenState();
}

class _SimpleChatScreenState extends State<SimpleChatScreen> {
  final TextEditingController messageController = TextEditingController();
  List<Message> messages = [];
  bool isLoading = false;
  String? targetAdminId; // Private var to hold the resolved ID
  RealtimeChannel? _subscription;
  final ScrollController _scrollController = ScrollController();

  @override
  void initState() {
    super.initState();
    targetAdminId = widget.adminId; // Use passed ID if available
    _initializeChat();
  }

  @override
  void dispose() {
    messageController.dispose();
    _scrollController.dispose();
    _subscription?.unsubscribe();
    super.dispose();
  }

  Future<void> _initializeChat() async {
    setState(() => isLoading = true);
    
    // Only fetch if not passed
    if (targetAdminId == null) {
      await _fetchAdminId();
    }

    if (targetAdminId != null) {
      await fetchMessages();
      _subscribeToRealtime();
    } else {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Admin not found. Cannot start chat.')),
        );
      }
    }
    if (mounted) setState(() => isLoading = false);
  }

  Future<void> _fetchAdminId() async {
    try {
      final response = await supabase
          .from('tbl_profiles')
          .select('id')
          .eq('role', 'admin')
          .limit(1)
          .maybeSingle();

      if (response != null && mounted) {
        setState(() {
          targetAdminId = response['id'] as String;
        });
      }
    } catch (e) {
      debugPrint('Error fetching admin ID: $e');
    }
  }

  Future<void> fetchMessages() async {
    try {
      final response = await supabase
          .from('tbl_messages')
          .select()
          .order('created_at', ascending: true);

      final data = response as List<dynamic>;
      if (mounted) {
        setState(() {
          messages = data
              .map((e) => Message.fromMap(e))
              .where((msg) {
                // Determine if message belongs to this chat session
                // 1. Sent by me (appId) to Admin
                // 2. Sent by Admin to me (appId)
                // 3. Broadcasts (optional, typically for everyone)
                
                final isMyMessage = (msg.senderId == widget.appId && msg.receiverId == targetAdminId);
                final isForMe = (msg.senderId == targetAdminId && msg.receiverId == widget.appId);
                
                return isMyMessage || isForMe; // || msg.isBroadcast; 
              })
              .map((msg) {
                // Decrypt content for display
                try {
                  return msg.copyWith(content: EncryptionHelper.decrypt(msg.content));
                } catch (e) {
                  return msg; // Return original if decryption fails (e.g. unencrypted legacy msg)
                }
              })
              .toList();
        });
        _scrollToBottom();
      }
    } catch (e) {
      debugPrint('Error fetching messages: $e');
    }
  }

  void _subscribeToRealtime() {
    _subscription = supabase
        .channel('public:tbl_messages')
        .onPostgresChanges(
          event: PostgresChangeEvent.insert,
          schema: 'public',
          table: 'tbl_messages',
          callback: (payload) {
            final rawMsg = Message.fromMap(payload.newRecord);
            
            // Apply filtering logic again for realtime updates
            final isMyMessage = (rawMsg.senderId == widget.appId && rawMsg.receiverId == targetAdminId);
            final isForMe = (rawMsg.senderId == targetAdminId && rawMsg.receiverId == widget.appId);

            if (isMyMessage || isForMe) {
               final decryptedMsg = rawMsg.copyWith(content: EncryptionHelper.decrypt(rawMsg.content));
               if (mounted) {
                setState(() {
                  messages.add(decryptedMsg);
                });
                _scrollToBottom();
              }
            }
          },
        )
        .subscribe();
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  Future<void> sendMessage() async {
    final content = messageController.text.trim();
    if (content.isEmpty || targetAdminId == null) return;

    // Encrypt before sending
    final encryptedContent = EncryptionHelper.encrypt(content);

    final message = Message(
      id: '', // Generated by DB
      senderId: widget.appId, // Using App ID as sender
      receiverId: targetAdminId,
      content: encryptedContent,
      isBroadcast: false,
      createdAt: DateTime.now(),
    );

    try {
      await supabase.from('tbl_messages').insert(message.toMap());
      messageController.clear();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to send: $e')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Support Chat', style: TextStyle(fontSize: 16)),
            Text('ID: ${widget.appId}', style: const TextStyle(fontSize: 10, fontWeight: FontWeight.normal)),
          ],
        ),
      ),
      body: Column(
        children: [
          Expanded(
            child: isLoading
                ? const Center(child: CircularProgressIndicator())
                : messages.isEmpty
                    ? const Center(child: Text("Start a conversation..."))
                    : ListView.builder(
                        controller: _scrollController,
                        itemCount: messages.length,
                        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 10),
                        itemBuilder: (context, index) {
                          final msg = messages[index];
                          final isMe = msg.senderId == widget.appId;
                          
                          return Align(
                            alignment: isMe ? Alignment.centerRight : Alignment.centerLeft,
                            child: Container(
                              margin: const EdgeInsets.symmetric(vertical: 2), // Reduced vertical margin
                              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6), // Reduced padding
                              constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.75),
                              decoration: BoxDecoration(
                                color: isMe ? Colors.blue[600] : Colors.grey[300],
                                borderRadius: BorderRadius.circular(16).copyWith(
                                  bottomRight: isMe ? const Radius.circular(0) : const Radius.circular(16),
                                  bottomLeft: isMe ? const Radius.circular(16) : const Radius.circular(0),
                                ),
                              ),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Text(
                                    msg.content,
                                    style: TextStyle(
                                      color: isMe ? Colors.white : Colors.black87,
                                      fontSize: 14,
                                    ),
                                  ),
                                  const SizedBox(height: 2),
                                  Text(
                                    DateFormat('hh:mm a').format(msg.createdAt.toLocal()),
                                    style: TextStyle(
                                      fontSize: 9,
                                      color: isMe ? Colors.white70 : Colors.black54,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          );
                        },
                      ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: messageController,
                    decoration: InputDecoration(
                      hintText: 'Type a message...',
                      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(24)),
                      filled: true,
                      fillColor: Colors.grey[100],
                    ),
                    minLines: 1,
                    maxLines: 3,
                  ),
                ),
                const SizedBox(width: 8),
                FloatingActionButton(
                  onPressed: sendMessage,
                  mini: true,
                  child: const Icon(Icons.send, size: 18),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
